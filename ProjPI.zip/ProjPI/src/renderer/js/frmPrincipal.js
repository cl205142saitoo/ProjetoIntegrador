const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
let clubesCarregados = [];
let idParaExcluirClube = null;

// ============================================================
// CLUBE -- CRUD completo, use como referencia pro de Atleta
// ============================================================

const carregarClubes = async () => {
  clubesCarregados = await window.api.listarClubes();

  const linhas = clubesCarregados
    .map(
      (clube_) => `
      <tr>
      <td>${escapeHtml(clube_.nome)}</td>
      <td>${escapeHtml(clube_.cidade)}</td>
      <td>${clube_.ano_fundacao}</td>
      <td>
        <button class="btn btn-sm btn-primary" onclick="editarClube(${clube_.id})">
          Editar
        </button>
        <button class="btn btn-sm btn-danger" onclick="abrirConfirmacaoExclusaoClube(${clube_.id})">
          Excluir
        </button>
        </td>
    </tr>`,
    )
    .join("");

  document.querySelector("#tbodyClubes").innerHTML = linhas || '<tr><td colspan="4" class="empty-row">Nenhum clube cadastrado ainda.</td></tr>';
  const total = document.querySelector("#clubes-total");
  if (total) total.textContent = clubesCarregados.length;
};

const editarClube = (id) => {
  const clube_ = clubesCarregados.find((c) => c.id === id);
  window.api.editarClube(clube_);
};

const abrirConfirmacaoExclusaoClube = (id) => {
  const clube_ = clubesCarregados.find((item) => item.id === id);

  document.querySelector("#nomeClubeExcluir").textContent = clube_.nome;
  idParaExcluirClube = id;

  const modal = new bootstrap.Modal(
    document.querySelector("#modalConfirmarExclusaoClube"),
  );
  modal.show();
};

document
  .querySelector("#btnConfirmarExclusaoClube")
  .addEventListener("click", async () => {
    await window.api.excluirClube(idParaExcluirClube);

    const modal = bootstrap.Modal.getInstance(
      document.querySelector("#modalConfirmarExclusaoClube"),
    );
    modal.hide();

    carregarClubes();
  });

carregarClubes();

// ============================================================
// ATLETA -- CRUD completo
// ============================================================

let atletasCarregados = [];
let idParaExcluirAtleta = null;

const carregarAtletas = async () => {
  atletasCarregados = await window.api.listarAtletas();

  const linhas = atletasCarregados
    .map(
      (atleta) => `
      <tr>
      <td>${escapeHtml(atleta.nome)}</td>
      <td>${escapeHtml(atleta.posicao)}</td>
      <td>${escapeHtml(atleta.pe_dominante)}</td>
      <td>${atleta.ano_nascimento}</td>
      <td>
        <button class="btn btn-sm btn-primary" onclick="editarAtleta(${atleta.id})">
          Editar
        </button>
        <button class="btn btn-sm btn-danger" onclick="abrirConfirmacaoExclusaoAtleta(${atleta.id})">
          Excluir
        </button>
        </td>
    </tr>`,
    )
    .join("");

  document.querySelector("#tbodyAtletas").innerHTML = linhas || '<tr><td colspan="5" class="empty-row">Nenhum atleta cadastrado ainda.</td></tr>';
  const total = document.querySelector("#atletas-total");
  if (total) total.textContent = atletasCarregados.length;
};

const editarAtleta = (id) => {
  const atleta = atletasCarregados.find((j) => j.id === id);
  window.api.editarAtleta(atleta);
};

const abrirConfirmacaoExclusaoAtleta = (id) => {
  const atleta = atletasCarregados.find((item) => item.id === id);

  document.querySelector("#nomeAtletaExcluir").textContent = atleta.nome;
  idParaExcluirAtleta = id;

  const modal = new bootstrap.Modal(
    document.querySelector("#modalConfirmarExclusaoAtleta"),
  );
  modal.show();
};

document
  .querySelector("#btnConfirmarExclusaoAtleta")
  .addEventListener("click", async () => {
    await window.api.excluirAtleta(idParaExcluirAtleta);

    const modal = bootstrap.Modal.getInstance(
      document.querySelector("#modalConfirmarExclusaoAtleta"),
    );
    modal.hide();

    carregarAtletas();
  });

carregarAtletas();

window.addEventListener("focus", () => {
  carregarClubes();
  carregarAtletas();
  carregarRelatorios();
});

window.editarClube = editarClube;
window.abrirConfirmacaoExclusaoClube = abrirConfirmacaoExclusaoClube;
window.editarAtleta = editarAtleta;
window.abrirConfirmacaoExclusaoAtleta = abrirConfirmacaoExclusaoAtleta;


// ============================================================
// CRUD DE RELATORIOS DE MATCHES
// ============================================================
let relatoriosCarregados = [];
let modalRelatorio;

const carregarRelatorios = async () => {
  const tbody = document.querySelector("#tbodyRelatorios");
  try {
    relatoriosCarregados = await window.api.listarRelatorios();
    tbody.innerHTML = relatoriosCarregados.map((r) => `
      <tr>
        <td>${escapeHtml(r.titulo)}</td><td>${escapeHtml(r.periodo)}</td>
        <td><strong>${Number(r.total_matches) || 0}</strong></td>
        <td>${Number(r.curtidas) || 0}</td><td>${Number(r.contatos) || 0}</td>
        <td>${escapeHtml(r.observacoes || "—")}</td>
        <td><button class="btn btn-sm btn-primary" onclick="editarRelatorio(${r.id})">Editar</button>
        <button class="btn btn-sm btn-danger" onclick="excluirRelatorio(${r.id})">Excluir</button></td>
      </tr>`).join("") || '<tr><td colspan="7" class="empty-row">Nenhum relatório cadastrado. Clique em “Novo relatório” para começar.</td></tr>';
    document.querySelector("#matches-total").textContent = relatoriosCarregados.reduce((s, r) => s + (Number(r.total_matches) || 0), 0);
  } catch (erro) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-row">Não foi possível carregar os relatórios. Confira se a tabela relatorio existe no MySQL.</td></tr>';
    console.error("Erro ao carregar relatórios:", erro);
  }
};

const limparFormularioRelatorio = () => {
  document.querySelector("#formRelatorio").reset();
  document.querySelector("#relatorioId").value = "";
  document.querySelector("#relatorioMatches").value = 0;
  document.querySelector("#relatorioCurtidas").value = 0;
  document.querySelector("#relatorioContatos").value = 0;
  document.querySelector("#erroRelatorio").textContent = "";
};

const abrirNovoRelatorio = () => {
  limparFormularioRelatorio();
  document.querySelector("#tituloModalRelatorio").textContent = "Novo relatório";
  modalRelatorio = bootstrap.Modal.getOrCreateInstance(document.querySelector("#modalRelatorio"));
  modalRelatorio.show();
};

const editarRelatorio = (id) => {
  const r = relatoriosCarregados.find((item) => Number(item.id) === Number(id));
  if (!r) return;
  document.querySelector("#relatorioId").value = r.id;
  document.querySelector("#relatorioTitulo").value = r.titulo || "";
  document.querySelector("#relatorioPeriodo").value = r.periodo || "";
  document.querySelector("#relatorioMatches").value = Number(r.total_matches) || 0;
  document.querySelector("#relatorioCurtidas").value = Number(r.curtidas) || 0;
  document.querySelector("#relatorioContatos").value = Number(r.contatos) || 0;
  document.querySelector("#relatorioObservacoes").value = r.observacoes || "";
  document.querySelector("#erroRelatorio").textContent = "";
  document.querySelector("#tituloModalRelatorio").textContent = "Editar relatório";
  modalRelatorio = bootstrap.Modal.getOrCreateInstance(document.querySelector("#modalRelatorio"));
  modalRelatorio.show();
};

const excluirRelatorio = async (id) => {
  const r = relatoriosCarregados.find((item) => Number(item.id) === Number(id));
  if (!r || !confirm(`Deseja excluir o relatório “${r.titulo}”? Esta ação não pode ser desfeita.`)) return;
  try { await window.api.excluirRelatorio(id); await carregarRelatorios(); }
  catch (erro) { alert("Não foi possível excluir o relatório. Confira a conexão com o banco de dados."); console.error(erro); }
};

document.querySelector("#formRelatorio").addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const id = document.querySelector("#relatorioId").value;
  const relatorio = {
    titulo: document.querySelector("#relatorioTitulo").value.trim(),
    periodo: document.querySelector("#relatorioPeriodo").value.trim(),
    total_matches: Number(document.querySelector("#relatorioMatches").value),
    curtidas: Number(document.querySelector("#relatorioCurtidas").value),
    contatos: Number(document.querySelector("#relatorioContatos").value),
    observacoes: document.querySelector("#relatorioObservacoes").value.trim()
  };
  if (!relatorio.titulo || !relatorio.periodo || Object.values(relatorio).some(v => typeof v === "number" && (!Number.isInteger(v) || v < 0))) {
    document.querySelector("#erroRelatorio").textContent = "Preencha título e período e informe números inteiros iguais ou maiores que zero.";
    return;
  }
  try {
    if (id) { relatorio.id = Number(id); await window.api.atualizarRelatorio(relatorio); }
    else { await window.api.criarRelatorio(relatorio); }
    modalRelatorio.hide();
    await carregarRelatorios();
  } catch (erro) {
    document.querySelector("#erroRelatorio").textContent = "Erro ao salvar. Confira se a tabela relatorio foi criada no MySQL.";
    console.error("Erro ao salvar relatório:", erro);
  }
});

window.abrirNovoRelatorio = abrirNovoRelatorio;
window.editarRelatorio = editarRelatorio;
window.excluirRelatorio = excluirRelatorio;
carregarRelatorios();
